import streamlit as st
import pandas as pd

#1. Create a streamlit title widget, this will be shown first

#2. Then create a streamlit title widget, this will be shown after title



#3. Create two streamlit slider widget for receiving a numerical value input


#4. Create a streamlit text widget to show the sum result of two slider values
# Create a streamlit subheader widget
